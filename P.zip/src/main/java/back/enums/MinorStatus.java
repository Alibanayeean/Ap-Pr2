package back.enums;

public enum MinorStatus {
    No, Reject, Accept, Wait;
}

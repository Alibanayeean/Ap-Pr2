package back.enums;

public enum EducationStatus {
    Studying, Graduated, Refuse, Wait;
}

package back.enums;

public enum Days {
    Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday;
}

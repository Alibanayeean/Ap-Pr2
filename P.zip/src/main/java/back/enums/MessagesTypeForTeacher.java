package back.enums;

public enum MessagesTypeForTeacher {
    getCourse, sendMessageInChatRoom;
}

package back.enums;

public enum College {
    EE, CE, CS, Math, Physics, Ch, Mechanic, Public;
}

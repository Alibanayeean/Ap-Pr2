package back.enums;


public enum TeacherDegree {
    FullProfessor, AssistantProfessor, AssociateProfessor;

}
package back.enums;

public enum Request{
    Accept, Reject, Wait
}

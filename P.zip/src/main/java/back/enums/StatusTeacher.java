package back.enums;

public enum StatusTeacher {
    EA, Boss, Simple
}

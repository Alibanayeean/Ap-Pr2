package back.enums;

public enum HomeWorkOrExamType {
    TEXT,
    FILE;
}

package back.enums;

public enum Grade{
    PHD,
    MS,
    BC;
}
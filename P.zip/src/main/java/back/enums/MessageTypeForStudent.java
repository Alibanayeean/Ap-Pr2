package back.enums;

public enum MessageTypeForStudent {
    simpleMessage , sendMessageInChatRoom;
}
